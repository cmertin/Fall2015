Clazz.declarePackage ("JU");
Clazz.load (["java.io.IOException"], "JU.GZIPException", null, function () {
c$ = Clazz.declareType (JU, "GZIPException", java.io.IOException);
});
