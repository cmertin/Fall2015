#!/bin/bash

python -W ignore SGD.py
